<head>
  <meta http-equiv="refresh" content="0.25;url=https://koppepan-orange.github.io/game-site/welcome.html">
</head>
なぜここに..?<br>
ここにくるべきではない、早く立ち去るのだ..!!